import React from 'react'
import './index.css';

const Header = () => {
  return (
    <div className='header'>
        <h3>TechMart</h3>
    </div>
  )
}

export default Header